/*
 * SPDX-License-Identifier: Apache-2.0
 */

import {ProductoContract} from './contract';

export {ProductoContract} from './contract';

export const contracts: any[] = [ProductoContract]